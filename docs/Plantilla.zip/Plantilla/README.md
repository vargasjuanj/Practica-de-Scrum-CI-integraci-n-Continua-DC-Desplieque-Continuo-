## [Tecnicatura Universitaria en Programación, UTN-FRM. Metodología de Sistemas. Profesor: Alberto Cortez](http://www.frm.utn.edu.ar)
## Plantilla para la práctica de ..
> Plantilla con Spring básico (API, test) 

## Estado del Código
[![Heroku broken](https://app-utn.herokuapp.com/system/version-badge)](https://app-utn.herokuapp.com/swagger-ui.html)

## Ecosistema
* Java
* Maven
* Logs
* JUnit5
* IntelliJ
* GitHub
* Travis-CI
* Sonar Cloud
* Better Code Hub
* Spring
* Heroku
* OpenAPI-Swagger



